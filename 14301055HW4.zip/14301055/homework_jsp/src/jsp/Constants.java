package jsp;

import java.io.File;

public class Constants {
 public static final String WEB_ROOT = System.getProperty("user.dir")
 + File.separator;
 public static final String WEB_SERVLET_ROOT = System.getProperty("user.dir")
 + File.separator + "target" + File.separator + "classes";
  
}
